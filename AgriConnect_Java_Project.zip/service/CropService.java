package service;

import dao.CropDAO;
import model.Crop;

import java.util.ArrayList;
import java.util.Scanner;

public class CropService {
    private final CropDAO dao = new CropDAO();
    private final Scanner sc = new Scanner(System.in);

    public void addCrop() {
        System.out.print("Enter farmer name: ");
        String farmer = sc.nextLine();

        System.out.print("Enter crop name: ");
        String name = sc.nextLine();

        double price;
        int qty;
        try {
            System.out.print("Enter price per kg: ");
            price = Double.parseDouble(sc.nextLine());
            System.out.print("Enter quantity (kg): ");
            qty = Integer.parseInt(sc.nextLine());
        } catch (NumberFormatException e) {
            System.out.println("Invalid input! Price and quantity must be numbers.");
            return;
        }

        Crop crop = new Crop(name, price, qty, farmer);
        dao.addCrop(crop);
        System.out.println("✅ Crop added successfully.");
    }

    public void listCrops() {
        ArrayList<Crop> crops = dao.getAllCrops();
        if (crops.isEmpty()) {
            System.out.println("No crops available.");
        } else {
            for (int i = 0; i < crops.size(); i++) {
                System.out.println((i + 1) + ". " + crops.get(i));
            }
        }
    }

    public void deleteCrop() {
        listCrops();
        System.out.print("Enter crop number to delete: ");
        try {
            int index = Integer.parseInt(sc.nextLine()) - 1;
            if (dao.deleteCrop(index)) {
                System.out.println("✅ Crop deleted.");
            } else {
                System.out.println("❌ Invalid index.");
            }
        } catch (Exception e) {
            System.out.println("❌ Error: " + e.getMessage());
        }
    }

    public void buyCrop() {
        ArrayList<Crop> crops = dao.getAllCrops();
        if (crops.isEmpty()) {
            System.out.println("No crops available.");
            return;
        }

        listCrops();
        System.out.print("Enter crop number to buy: ");
        int index;
        try {
            index = Integer.parseInt(sc.nextLine()) - 1;
            if (index < 0 || index >= crops.size()) {
                System.out.println("❌ Invalid selection.");
                return;
            }
        } catch (NumberFormatException e) {
            System.out.println("❌ Invalid input.");
            return;
        }

        Crop selected = crops.get(index);
        System.out.print("Enter quantity to buy (kg): ");
        int qty;
        try {
            qty = Integer.parseInt(sc.nextLine());
        } catch (NumberFormatException e) {
            System.out.println("❌ Invalid quantity.");
            return;
        }

        if (qty <= 0 || qty > selected.getQuantity()) {
            System.out.println("❌ Quantity not available.");
            return;
        }

        double total = qty * selected.getPricePerKg();
        selected.setQuantity(selected.getQuantity() - qty);
        dao.saveAllCrops(crops);

        System.out.printf("✅ Purchase successful! Total cost: ₹%.2f%n", total);
    }
}