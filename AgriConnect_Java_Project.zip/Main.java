import service.CropService;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        CropService service = new CropService();
        Scanner sc = new Scanner(System.in);

        while (true) {
            System.out.println("\n=== AgriConnect Menu ===");
            System.out.println("1. Add Crop");
            System.out.println("2. View Crops");
            System.out.println("3. Delete Crop");
            System.out.println("4. Buy Crop");
            System.out.println("5. Exit");
            System.out.print("Choose: ");

            String choice = sc.nextLine();

            switch (choice) {
                case "1":
                    service.addCrop();
                    break;
                case "2":
                    service.listCrops();
                    break;
                case "3":
                    service.deleteCrop();
                    break;
                case "4":
                    service.buyCrop();
                    break;
                case "5":
                    System.out.println("Exiting. Goodbye!");
                    return;
                default:
                    System.out.println("❌ Invalid choice.");
            }
        }
    }
}