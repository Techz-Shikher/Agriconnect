package dao;

import model.Crop;

import java.io.*;
import java.util.ArrayList;

public class CropDAO {
    private static final String FILE_NAME = "crops.dat";

    public void addCrop(Crop crop) {
        ArrayList<Crop> crops = getAllCrops();
        crops.add(crop);
        saveAllCrops(crops);
    }

    public ArrayList<Crop> getAllCrops() {
        ArrayList<Crop> crops = new ArrayList<>();
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(FILE_NAME))) {
            crops = (ArrayList<Crop>) ois.readObject();
        } catch (Exception ignored) {}
        return crops;
    }

    public void saveAllCrops(ArrayList<Crop> crops) {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(FILE_NAME))) {
            oos.writeObject(crops);
        } catch (IOException e) {
            System.out.println("Error saving crops: " + e.getMessage());
        }
    }

    public boolean deleteCrop(int index) {
        ArrayList<Crop> crops = getAllCrops();
        if (index >= 0 && index < crops.size()) {
            crops.remove(index);
            saveAllCrops(crops);
            return true;
        }
        return false;
    }
}