package model;

import java.io.Serializable;

public class Crop implements Serializable {
    private String name;
    private double pricePerKg;
    private int quantity;
    private String farmerName;

    public Crop(String name, double pricePerKg, int quantity, String farmerName) {
        this.name = name;
        this.pricePerKg = pricePerKg;
        this.quantity = quantity;
        this.farmerName = farmerName;
    }

    public String getName() {
        return name;
    }

    public double getPricePerKg() {
        return pricePerKg;
    }

    public int getQuantity() {
        return quantity;
    }

    public String getFarmerName() {
        return farmerName;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public String toString() {
        return String.format("Crop: %s | ₹%.2f/kg | Qty: %dkg | Farmer: %s",
                name, pricePerKg, quantity, farmerName);
    }
}