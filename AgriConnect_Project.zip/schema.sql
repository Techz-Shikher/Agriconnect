CREATE DATABASE IF NOT EXISTS agriconnect;
USE agriconnect;

CREATE TABLE IF NOT EXISTS crop_sales (
    id INT AUTO_INCREMENT PRIMARY KEY,
    crop_name VARCHAR(50),
    quantity INT,
    price DOUBLE,
    total DOUBLE,
    sale_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
