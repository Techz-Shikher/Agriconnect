# AgriConnect

## Description
AgriConnect is a Java-based GUI application that allows farmers or sellers to input crop details and calculate pricing. It stores the data in a MySQL database using JDBC.

## Features
- Java Swing GUI to input crop name, quantity, and price.
- Calculates total price automatically.
- Saves crop sale data to MySQL.
- Follows modular design using Model, DAO, and DB utility classes.

## Requirements
- JDK 8 or above
- MySQL Server
- MySQL Connector/J (place in `lib/` folder)

## Setup Instructions
1. **Clone the repo** or download the ZIP.
2. **Run `schema.sql`** in your MySQL client to create the database and table.
3. **Update DB credentials** in `DBConnection.java`.
4. **Compile and run**:
   ```bash
   cd src
   javac -cp "../lib/mysql-connector-java.jar" *.java
   java -cp ".;../lib/mysql-connector-java.jar" AgriConnectMain
   ```

## Project Structure
```
AgriConnect/
├── src/
│   ├── AgriConnectMain.java
│   ├── Crop.java
│   ├── CropDAO.java
│   └── DBConnection.java
├── lib/
│   └── mysql-connector-java.jar (not included)
├── README.md
├── schema.sql
└── .gitignore
```
