import java.sql.*;

public class CropDAO {
    public void insertCrop(Crop crop) {
        try (Connection conn = DBConnection.getConnection()) {
            String query = "INSERT INTO crop_sales (crop_name, quantity, price, total) VALUES (?, ?, ?, ?)";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setString(1, crop.getName());
            stmt.setInt(2, crop.getQuantity());
            stmt.setDouble(3, crop.getPrice());
            stmt.setDouble(4, crop.getTotal());
            stmt.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
